import pygame
import random
import sys
import time
import math

# Initialize pygame
pygame.init()

# Game constants
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
FPS = 60
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (50, 205, 50)
RED = (220, 60, 60)
BLUE = (30, 144, 255)
YELLOW = (255, 215, 0)
PURPLE = (147, 112, 219)
CYAN = (0, 206, 209)
GRAY = (169, 169, 169)
DARK_BLUE = (25, 25, 112)

# Set up the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("CyberShield Quest - Digital Safety Awareness")
clock = pygame.time.Clock()

# Fonts
title_font = pygame.font.SysFont("Arial", 60, bold=True)
header_font = pygame.font.SysFont("Arial", 36, bold=True)
normal_font = pygame.font.SysFont("Arial", 28)
small_font = pygame.font.SysFont("Arial", 22)
score_font = pygame.font.SysFont("Arial", 32, bold=True)

# Game state
class GameState:
    MENU = 0
    PHISHING_MISSION = 1
    PASSWORD_MISSION = 2
    LINK_MISSION = 3
    SCAM_MISSION = 4
    GAME_OVER = 5
    WIN = 6

# Player data
class Player:
    def __init__(self):
        self.cyber_safety_score = 100  # Start with 100 points
        self.mission_completed = 0
        self.total_missions = 4
        self.time_penalty = 0
        
    def add_score(self, points):
        self.cyber_safety_score = max(0, min(100, self.cyber_safety_score + points))
    
    def complete_mission(self):
        self.mission_completed += 1
    
    def is_game_won(self):
        return self.mission_completed >= self.total_missions

# Initialize player
player = Player()

# Mission timers
mission_start_time = 0
mission_time_limit = 30  # 30 seconds per mission

# Current game state
game_state = GameState.MENU

# Button class for UI
class Button:
    def __init__(self, x, y, width, height, text, color=BLUE, hover_color=CYAN):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.is_hovered = False
        
    def draw(self, surface):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        pygame.draw.rect(surface, WHITE, self.rect, 3, border_radius=12)
        
        text_surf = normal_font.render(self.text, True, WHITE)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)
        
    def check_hover(self, pos):
        self.is_hovered = self.rect.collidepoint(pos)
        return self.is_hovered
        
    def is_clicked(self, pos, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            return self.rect.collidepoint(pos)
        return False

# Mission 1: Phishing Email Detection
phishing_emails = [
    {
        "sender": "security@amaz0n.com",
        "subject": "URGENT: Your account has been compromised!",
        "body": "Dear customer, we detected suspicious activity on your account. Click the link below to verify your identity immediately.",
        "link": "http://amaz0n-secure-login.com",
        "is_phishing": True
    },
    {
        "sender": "support@netflix.com",
        "subject": "Update your payment information",
        "body": "We couldn't process your last payment. Please update your payment details to avoid service interruption.",
        "link": "https://netflix.com/account/payment",
        "is_phishing": False
    },
    {
        "sender": "no-reply@paypal-security.com",
        "subject": "Unauthorized login attempt detected",
        "body": "We noticed a login attempt from a new device. If this wasn't you, please verify your account now.",
        "link": "http://paypal-verification-center.com",
        "is_phishing": True
    },
    {
        "sender": "noreply@microsoft.com",
        "subject": "Your Microsoft 365 subscription is expiring",
        "body": "Your subscription will expire in 7 days. Renew now to continue using all features.",
        "link": "https://account.microsoft.com/services",
        "is_phishing": False
    }
]

selected_phishing_email = None
phishing_buttons = []

# Mission 2: Strong Password Creation
password_strength_rules = [
    "At least 8 characters long",
    "Contains uppercase and lowercase letters",
    "Includes at least one number (0-9)",
    "Includes at least one special character (!@#$%^&*)",
    "Not a common password (password, 123456, etc.)"
]

password_input = ""
password_strength = 0
password_feedback = ""

# Mission 3: Suspicious Link Identification
suspicious_links = [
    ("http://secure-facebook-login.com", True),
    ("https://www.facebook.com/login", False),
    ("http://appleid-verification.net", True),
    ("https://id.apple.com", False),
    ("http://bankofamerica.secure-login.com", True),
    ("https://www.bankofamerica.com", False),
    ("http://microsoft-update-center.com", True),
    ("https://support.microsoft.com", False)
]

link_mission_links = []
link_selection = None

# Mission 4: Online Scam Detection
scam_scenarios = [
    {
        "title": "Tech Support Scam",
        "description": "You receive a call from someone claiming to be from Microsoft. They say your computer has a virus and ask for remote access to fix it.",
        "options": ["Grant them remote access", "Hang up and report the call", "Provide your credit card for 'security software'"],
        "correct": 1
    },
    {
        "title": "Lottery Scam",
        "description": "You get an email saying you won an international lottery you never entered. They ask for a small fee to release your winnings.",
        "options": ["Pay the fee to claim your prize", "Delete the email and ignore it", "Provide your bank details to receive the money"],
        "correct": 1
    },
    {
        "title": "Social Media Impersonation",
        "description": "A friend messages you on social media asking for emergency money. The writing style seems different from usual.",
        "options": ["Send money immediately to help", "Call your friend to verify the request", "Ignore the message"],
        "correct": 1
    }
]

current_scam = None
scam_selected = None

# Initialize buttons
def init_buttons():
    global start_button, mission_buttons, phishing_buttons, continue_button, menu_button
    
    # Main menu buttons
    start_button = Button(SCREEN_WIDTH//2 - 150, 400, 300, 60, "START QUEST", GREEN)
    
    # Mission selection buttons (for later expansion)
    mission_buttons = [
        Button(200, 300, 200, 80, "Phishing\nDetection", RED),
        Button(450, 300, 200, 80, "Password\nSecurity", BLUE),
        Button(700, 300, 200, 80, "Link Safety", YELLOW),
        Button(SCREEN_WIDTH//2 - 100, 450, 200, 80, "Scam Alert", PURPLE)
    ]
    
    # Game over buttons
    continue_button = Button(SCREEN_WIDTH//2 - 150, 500, 300, 60, "CONTINUE", GREEN)
    menu_button = Button(SCREEN_WIDTH//2 - 150, 580, 300, 60, "MAIN MENU", BLUE)

# Initialize the game
init_buttons()

# Draw background
def draw_background():
    # Gradient background
    for y in range(0, SCREEN_HEIGHT, 2):
        # Create a gradient from dark blue to lighter blue
        color_value = max(0, min(255, 25 + y // 4))
        pygame.draw.rect(screen, (25, 25, color_value), (0, y, SCREEN_WIDTH, 2))
    
    # Draw cyber-themed pattern
    for i in range(20):
        x = random.randint(0, SCREEN_WIDTH)
        y = random.randint(0, SCREEN_HEIGHT)
        size = random.randint(1, 3)
        pygame.draw.circle(screen, (0, 150, 255, 100), (x, y), size)
    
    # Draw shield logo
    shield_x, shield_y = SCREEN_WIDTH - 100, 100
    pygame.draw.polygon(screen, CYAN, [
        (shield_x, shield_y - 40),
        (shield_x - 30, shield_y - 10),
        (shield_x - 30, shield_y + 30),
        (shield_x, shield_y + 60),
        (shield_x + 30, shield_y + 30),
        (shield_x + 30, shield_y - 10)
    ], 3)

# Draw main menu
def draw_menu():
    draw_background()
    
    # Game title
    title = title_font.render("CYBERSHIELD QUEST", True, CYAN)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))
    
    subtitle = header_font.render("Digital Safety Awareness Game", True, WHITE)
    screen.blit(subtitle, (SCREEN_WIDTH//2 - subtitle.get_width()//2, 180))
    
    # Instructions
    instructions = [
        "Complete cybersecurity missions to protect your digital identity.",
        "Each mission tests your knowledge of online safety practices.",
        "Your Cyber Safety Score reflects how well you protect yourself.",
        "Complete all missions to become a Cyber Safety Expert!"
    ]
    
    for i, line in enumerate(instructions):
        text = small_font.render(line, True, WHITE)
        screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, 250 + i*30))
    
    # Start button
    start_button.draw(screen)
    
    # Draw player score if available
    if player.cyber_safety_score < 100:
        score_text = score_font.render(f"Current Cyber Safety Score: {player.cyber_safety_score}%", True, YELLOW)
        screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, 500))
    
    pygame.display.flip()

# Start a mission
def start_mission(mission_type):
    global game_state, mission_start_time, selected_phishing_email, phishing_buttons
    global password_input, password_strength, password_feedback
    global link_mission_links, link_selection
    global current_scam, scam_selected
    
    game_state = mission_type
    mission_start_time = time.time()
    
    # Mission-specific initialization
    if mission_type == GameState.PHISHING_MISSION:
        # Select a random phishing email
        selected_phishing_email = random.choice(phishing_emails)
        # Create buttons for this mission
        phishing_buttons = [
            Button(SCREEN_WIDTH//2 - 150, 450, 300, 60, "PHISHING EMAIL", RED),
            Button(SCREEN_WIDTH//2 - 150, 530, 300, 60, "LEGITIMATE EMAIL", GREEN)
        ]
    
    elif mission_type == GameState.PASSWORD_MISSION:
        password_input = ""
        password_strength = 0
        password_feedback = "Type a password to check its strength"
    
    elif mission_type == GameState.LINK_MISSION:
        # Select 4 random links (2 phishing, 2 legitimate)
        link_mission_links = random.sample(suspicious_links, 4)
        link_selection = None
    
    elif mission_type == GameState.SCAM_MISSION:
        # Select a random scam scenario
        current_scam = random.choice(scam_scenarios)
        scam_selected = None

# Draw mission timer
def draw_timer():
    time_left = max(0, mission_time_limit - (time.time() - mission_start_time))
    timer_text = score_font.render(f"Time Left: {int(time_left)}s", True, YELLOW)
    screen.blit(timer_text, (SCREEN_WIDTH - timer_text.get_width() - 20, 20))
    
    # Check if time is up
    if time_left <= 0:
        player.add_score(-10)  # Penalty for running out of time
        return GameState.GAME_OVER
    return game_state

# Mission 1: Phishing Email Detection
def draw_phishing_mission():
    global game_state
    
    draw_background()
    
    # Mission title
    title = header_font.render("MISSION 1: Detect Phishing Emails", True, RED)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 30))
    
    # Instructions
    instructions = normal_font.render("Is this email legitimate or a phishing attempt?", True, WHITE)
    screen.blit(instructions, (SCREEN_WIDTH//2 - instructions.get_width()//2, 90))
    
    # Draw email box
    email_rect = pygame.Rect(100, 150, SCREEN_WIDTH - 200, 250)
    pygame.draw.rect(screen, (40, 40, 60), email_rect, border_radius=10)
    pygame.draw.rect(screen, WHITE, email_rect, 2, border_radius=10)
    
    # Email content
    if selected_phishing_email:
        sender = normal_font.render(f"From: {selected_phishing_email['sender']}", True, WHITE)
        subject = normal_font.render(f"Subject: {selected_phishing_email['subject']}", True, YELLOW)
        body_lines = []
        body_text = selected_phishing_email['body']
        
        # Split body text into lines
        words = body_text.split()
        line = ""
        for word in words:
            test_line = line + word + " "
            if normal_font.size(test_line)[0] < SCREEN_WIDTH - 250:
                line = test_line
            else:
                body_lines.append(line)
                line = word + " "
        if line:
            body_lines.append(line)
        
        link = normal_font.render(f"Link: {selected_phishing_email['link']}", True, CYAN)
        
        # Draw email content
        screen.blit(sender, (120, 170))
        screen.blit(subject, (120, 220))
        
        for i, line in enumerate(body_lines):
            line_surface = small_font.render(line, True, WHITE)
            screen.blit(line_surface, (120, 270 + i*30))
        
        screen.blit(link, (120, 370))
    
    # Draw buttons
    for button in phishing_buttons:
        button.draw(screen)
    
    # Draw timer
    game_state = draw_timer()
    
    pygame.display.flip()

# Mission 2: Strong Password Creation
def draw_password_mission():
    global game_state, password_input, password_strength, password_feedback
    
    draw_background()
    
    # Mission title
    title = header_font.render("MISSION 2: Create a Strong Password", True, BLUE)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 30))
    
    # Instructions
    instructions = normal_font.render("Type a password and check if it follows security rules:", True, WHITE)
    screen.blit(instructions, (SCREEN_WIDTH//2 - instructions.get_width()//2, 90))
    
    # Password input box
    input_rect = pygame.Rect(SCREEN_WIDTH//2 - 200, 150, 400, 50)
    pygame.draw.rect(screen, (40, 40, 60), input_rect, border_radius=8)
    pygame.draw.rect(screen, CYAN if len(password_input) > 0 else GRAY, input_rect, 2, border_radius=8)
    
    # Show password (with * for characters)
    display_password = "*" * len(password_input)
    password_text = normal_font.render(display_password, True, WHITE)
    screen.blit(password_text, (input_rect.x + 15, input_rect.y + 10))
    
    # Submit button
    submit_button = Button(SCREEN_WIDTH//2 - 100, 220, 200, 50, "CHECK PASSWORD", GREEN)
    submit_button.draw(screen)
    
    # Password rules
    rules_title = normal_font.render("Password Security Rules:", True, YELLOW)
    screen.blit(rules_title, (100, 300))
    
    for i, rule in enumerate(password_strength_rules):
        rule_text = small_font.render(f"✓ {rule}" if i < password_strength else f"✗ {rule}", 
                                      True, GREEN if i < password_strength else RED)
        screen.blit(rule_text, (120, 340 + i*35))
    
    # Password strength meter
    strength_x = SCREEN_WIDTH - 300
    pygame.draw.rect(screen, GRAY, (strength_x, 300, 200, 30), border_radius=5)
    
    # Strength colors
    if password_strength <= 2:
        strength_color = RED
        strength_label = "WEAK"
    elif password_strength == 3:
        strength_color = YELLOW
        strength_label = "MEDIUM"
    else:
        strength_color = GREEN
        strength_label = "STRONG"
    
    # Fill strength meter
    fill_width = (password_strength / 5) * 200
    pygame.draw.rect(screen, strength_color, (strength_x, 300, fill_width, 30), border_radius=5)
    
    strength_text = normal_font.render(f"Strength: {strength_label}", True, strength_color)
    screen.blit(strength_text, (strength_x, 340))
    
    # Feedback
    feedback_text = normal_font.render(password_feedback, True, WHITE)
    screen.blit(feedback_text, (SCREEN_WIDTH//2 - feedback_text.get_width()//2, 550))
    
    # Continue button when password is strong
    if password_strength >= 4:
        continue_btn = Button(SCREEN_WIDTH//2 - 150, 600, 300, 50, "CONTINUE TO NEXT MISSION", GREEN)
        continue_btn.draw(screen)
    
    # Draw timer
    game_state = draw_timer()
    
    pygame.display.flip()

# Mission 3: Suspicious Link Identification
def draw_link_mission():
    global game_state, link_selection
    
    draw_background()
    
    # Mission title
    title = header_font.render("MISSION 3: Identify Suspicious Links", True, YELLOW)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 30))
    
    # Instructions
    instructions = normal_font.render("Click on the links that look suspicious or dangerous:", True, WHITE)
    screen.blit(instructions, (SCREEN_WIDTH//2 - instructions.get_width()//2, 90))
    
    # Draw links
    link_buttons = []
    for i, (link, is_suspicious) in enumerate(link_mission_links):
        x = 150 if i % 2 == 0 else SCREEN_WIDTH - 450
        y = 180 + (i // 2) * 120
        
        # Determine button color
        if link_selection == i:
            color = RED if is_suspicious else GREEN
        else:
            color = GRAY
        
        link_button = Button(x, y, 300, 80, link, color)
        link_button.draw(screen)
        link_buttons.append((link_button, is_suspicious))
    
    # Check button
    check_button = Button(SCREEN_WIDTH//2 - 100, 550, 200, 60, "CHECK SELECTION", BLUE)
    check_button.draw(screen)
    
    # Feedback
    feedback = ""
    if link_selection is not None:
        selected_link, is_suspicious = link_mission_links[link_selection]
        feedback = f"Selected: {selected_link} - {'SUSPICIOUS' if is_suspicious else 'SAFE'}"
    
    feedback_text = normal_font.render(feedback, True, WHITE)
    screen.blit(feedback_text, (SCREEN_WIDTH//2 - feedback_text.get_width()//2, 480))
    
    # Instructions for checking
    if link_selection is not None:
        check_text = small_font.render("Click CHECK SELECTION to verify your answer", True, CYAN)
        screen.blit(check_text, (SCREEN_WIDTH//2 - check_text.get_width()//2, 630))
    
    # Draw timer
    game_state = draw_timer()
    
    pygame.display.flip()

# Mission 4: Online Scam Detection
def draw_scam_mission():
    global game_state, scam_selected
    
    draw_background()
    
    # Mission title
    title = header_font.render("MISSION 4: Detect Online Scams", True, PURPLE)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 30))
    
    if current_scam:
        # Scenario description
        scenario_title = normal_font.render(current_scam["title"], True, YELLOW)
        screen.blit(scenario_title, (SCREEN_WIDTH//2 - scenario_title.get_width()//2, 100))
        
        # Wrap description text
        desc_lines = []
        words = current_scam["description"].split()
        line = ""
        for word in words:
            test_line = line + word + " "
            if normal_font.size(test_line)[0] < SCREEN_WIDTH - 100:
                line = test_line
            else:
                desc_lines.append(line)
                line = word + " "
        if line:
            desc_lines.append(line)
        
        for i, line in enumerate(desc_lines):
            line_surface = small_font.render(line, True, WHITE)
            screen.blit(line_surface, (SCREEN_WIDTH//2 - line_surface.get_width()//2, 140 + i*30))
        
        # Draw options
        option_buttons = []
        for i, option in enumerate(current_scam["options"]):
            y_pos = 280 + i * 100
            
            # Determine button color
            if scam_selected == i:
                color = GREEN if i == current_scam["correct"] else RED
            else:
                color = BLUE
            
            option_button = Button(SCREEN_WIDTH//2 - 300, y_pos, 600, 80, option, color)
            option_button.draw(screen)
            option_buttons.append(option_button)
        
        # Instructions
        if scam_selected is None:
            instructions = normal_font.render("Select the safest response to this scenario:", True, CYAN)
            screen.blit(instructions, (SCREEN_WIDTH//2 - instructions.get_width()//2, 600))
        else:
            feedback = "CORRECT! This is the safest response." if scam_selected == current_scam["correct"] else "INCORRECT! This response could put you at risk."
            feedback_color = GREEN if scam_selected == current_scam["correct"] else RED
            feedback_text = normal_font.render(feedback, True, feedback_color)
            screen.blit(feedback_text, (SCREEN_WIDTH//2 - feedback_text.get_width()//2, 600))
            
            # Continue button
            continue_btn = Button(SCREEN_WIDTH//2 - 150, 650, 300, 50, "CONTINUE", GREEN)
            continue_btn.draw(screen)
    
    # Draw timer
    game_state = draw_timer()
    
    pygame.display.flip()

# Draw game over screen
def draw_game_over():
    draw_background()
    
    # Game over title
    title = title_font.render("MISSION RESULTS", True, RED)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))
    
    # Score display
    score_text = header_font.render(f"Cyber Safety Score: {player.cyber_safety_score}%", True, YELLOW)
    screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, 200))
    
    # Missions completed
    missions_text = normal_font.render(f"Missions Completed: {player.mission_completed}/{player.total_missions}", True, WHITE)
    screen.blit(missions_text, (SCREEN_WIDTH//2 - missions_text.get_width()//2, 260))
    
    # Feedback based on score
    if player.cyber_safety_score >= 80:
        feedback = "Excellent! You're a Cyber Safety Expert!"
        color = GREEN
    elif player.cyber_safety_score >= 60:
        feedback = "Good job! You have solid cyber safety knowledge."
        color = YELLOW
    elif player.cyber_safety_score >= 40:
        feedback = "You need to improve your digital safety practices."
        color = ORANGE = (255, 165, 0)
    else:
        feedback = "You're at high risk online. Please review cyber safety tips."
        color = RED
    
    feedback_text = normal_font.render(feedback, True, color)
    screen.blit(feedback_text, (SCREEN_WIDTH//2 - feedback_text.get_width()//2, 320))
    
    # Safety tips
    tips_title = normal_font.render("Cyber Safety Tips:", True, CYAN)
    screen.blit(tips_title, (SCREEN_WIDTH//2 - tips_title.get_width()//2, 380))
    
    tips = [
        "1. Never click suspicious links in emails",
        "2. Use strong, unique passwords for each account",
        "3. Enable two-factor authentication when possible",
        "4. Be skeptical of unsolicited requests for personal information",
        "5. Keep your software and antivirus updated"
    ]
    
    for i, tip in enumerate(tips):
        tip_text = small_font.render(tip, True, WHITE)
        screen.blit(tip_text, (SCREEN_WIDTH//2 - tip_text.get_width()//2, 420 + i*30))
    
    # Buttons
    continue_button.draw(screen)
    menu_button.draw(screen)
    
    pygame.display.flip()

# Draw win screen
def draw_win():
    draw_background()
    
    # Win title
    title = title_font.render("QUEST COMPLETE!", True, GREEN)
    screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))
    
    # Congratulations
    congrats = header_font.render("You've mastered digital safety!", True, YELLOW)
    screen.blit(congrats, (SCREEN_WIDTH//2 - congrats.get_width()//2, 180))
    
    # Score display
    score_text = header_font.render(f"Final Cyber Safety Score: {player.cyber_safety_score}%", True, CYAN)
    screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, 250))
    
    # Certificate
    cert_rect = pygame.Rect(SCREEN_WIDTH//2 - 300, 320, 600, 200)
    pygame.draw.rect(screen, (255, 255, 240), cert_rect, border_radius=15)
    pygame.draw.rect(screen, GOLD := (212, 175, 55), cert_rect, 5, border_radius=15)
    
    cert_title = title_font.render("CYBER SAFETY EXPERT", True, DARK_BLUE)
    screen.blit(cert_title, (SCREEN_WIDTH//2 - cert_title.get_width()//2, 350))
    
    cert_name = normal_font.render("Awarded for completing CyberShield Quest", True, BLACK)
    screen.blit(cert_name, (SCREEN_WIDTH//2 - cert_name.get_width()//2, 420))
    
    cert_score = normal_font.render(f"With a safety score of {player.cyber_safety_score}%", True, BLACK)
    screen.blit(cert_score, (SCREEN_WIDTH//2 - cert_score.get_width()//2, 470))
    
    # Continue button
    continue_button.draw(screen)
    
    pygame.display.flip()

# Check password strength
def check_password_strength(password):
    strength = 0
    
    # Check length
    if len(password) >= 8:
        strength += 1
    
    # Check for uppercase and lowercase
    if any(c.isupper() for c in password) and any(c.islower() for c in password):
        strength += 1
    
    # Check for numbers
    if any(c.isdigit() for c in password):
        strength += 1
    
    # Check for special characters
    special_chars = "!@#$%^&*"
    if any(c in special_chars for c in password):
        strength += 1
    
    # Check if it's not a common password
    common_passwords = ["password", "123456", "qwerty", "letmein", "welcome"]
    if password.lower() not in common_passwords:
        strength += 1
    
    return strength

# Check link mission completion
def check_link_mission():
    # Player needs to select at least 2 suspicious links correctly
    # For simplicity, we'll check if they selected any suspicious link
    if link_selection is not None:
        selected_link, is_suspicious = link_mission_links[link_selection]
        if is_suspicious:
            player.add_score(15)
            player.complete_mission()
            return True
        else:
            player.add_score(-10)
    return False

# Main game loop
def main():
    global game_state, password_input, password_strength, password_feedback
    global link_selection, scam_selected, player
    
    running = True
    
    while running:
        mouse_pos = pygame.mouse.get_pos()
        
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Handle main menu
            if game_state == GameState.MENU:
                start_button.check_hover(mouse_pos)
                if start_button.is_clicked(mouse_pos, event):
                    start_mission(GameState.PHISHING_MISSION)
            
            # Handle phishing mission
            elif game_state == GameState.PHISHING_MISSION:
                for i, button in enumerate(phishing_buttons):
                    button.check_hover(mouse_pos)
                    if button.is_clicked(mouse_pos, event):
                        # Check if answer is correct
                        is_phishing = selected_phishing_email["is_phishing"]
                        player_chose_phishing = (i == 0)  # First button is "PHISHING EMAIL"
                        
                        if is_phishing == player_chose_phishing:
                            player.add_score(20)
                            player.complete_mission()
                            # Move to next mission
                            start_mission(GameState.PASSWORD_MISSION)
                        else:
                            player.add_score(-15)
                            game_state = GameState.GAME_OVER
            
            # Handle password mission
            elif game_state == GameState.PASSWORD_MISSION:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        # Check password when Enter is pressed
                        password_strength = check_password_strength(password_input)
                        if password_strength >= 4:
                            password_feedback = "Excellent! This is a strong password."
                            player.add_score(20)
                            player.complete_mission()
                        elif password_strength >= 3:
                            password_feedback = "Good, but could be stronger. Try adding special characters."
                            player.add_score(10)
                        elif password_strength >= 2:
                            password_feedback = "Weak password. Review the rules above."
                            player.add_score(5)
                        else:
                            password_feedback = "Very weak password. Try again."
                            player.add_score(-5)
                    elif event.key == pygame.K_BACKSPACE:
                        password_input = password_input[:-1]
                        password_strength = check_password_strength(password_input)
                    else:
                        # Limit password length
                        if len(password_input) < 20:
                            password_input += event.unicode
                            password_strength = check_password_strength(password_input)
                
                # Check for button clicks
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check submit button
                    submit_rect = pygame.Rect(SCREEN_WIDTH//2 - 100, 220, 200, 50)
                    if submit_rect.collidepoint(mouse_pos):
                        password_strength = check_password_strength(password_input)
                        if password_strength >= 4:
                            password_feedback = "Excellent! This is a strong password."
                            player.add_score(20)
                            player.complete_mission()
                        elif password_strength >= 3:
                            password_feedback = "Good, but could be stronger. Try adding special characters."
                            player.add_score(10)
                        elif password_strength >= 2:
                            password_feedback = "Weak password. Review the rules above."
                            player.add_score(5)
                        else:
                            password_feedback = "Very weak password. Try again."
                            player.add_score(-5)
                    
                    # Check continue button
                    if password_strength >= 4:
                        continue_rect = pygame.Rect(SCREEN_WIDTH//2 - 150, 600, 300, 50)
                        if continue_rect.collidepoint(mouse_pos):
                            start_mission(GameState.LINK_MISSION)
            
            # Handle link mission
            elif game_state == GameState.LINK_MISSION:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check link buttons
                    for i in range(len(link_mission_links)):
                        x = 150 if i % 2 == 0 else SCREEN_WIDTH - 450
                        y = 180 + (i // 2) * 120
                        link_rect = pygame.Rect(x, y, 300, 80)
                        
                        if link_rect.collidepoint(mouse_pos):
                            link_selection = i
                    
                    # Check "Check Selection" button
                    check_rect = pygame.Rect(SCREEN_WIDTH//2 - 100, 550, 200, 60)
                    if check_rect.collidepoint(mouse_pos) and link_selection is not None:
                        selected_link, is_suspicious = link_mission_links[link_selection]
                        if is_suspicious:
                            player.add_score(15)
                            player.complete_mission()
                            start_mission(GameState.SCAM_MISSION)
                        else:
                            player.add_score(-10)
                            game_state = GameState.GAME_OVER
            
            # Handle scam mission
            elif game_state == GameState.SCAM_MISSION:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check option buttons
                    for i in range(len(current_scam["options"])):
                        y_pos = 280 + i * 100
                        option_rect = pygame.Rect(SCREEN_WIDTH//2 - 300, y_pos, 600, 80)
                        
                        if option_rect.collidepoint(mouse_pos):
                            scam_selected = i
                    
                    # Check continue button if answer is selected
                    if scam_selected is not None:
                        continue_rect = pygame.Rect(SCREEN_WIDTH//2 - 150, 650, 300, 50)
                        if continue_rect.collidepoint(mouse_pos):
                            if scam_selected == current_scam["correct"]:
                                player.add_score(20)
                                player.complete_mission()
                                
                                # Check if all missions are completed
                                if player.is_game_won():
                                    game_state = GameState.WIN
                                else:
                                    # For now, go to game over with results
                                    game_state = GameState.GAME_OVER
                            else:
                                player.add_score(-15)
                                game_state = GameState.GAME_OVER
            
            # Handle game over screen
            elif game_state == GameState.GAME_OVER:
                continue_button.check_hover(mouse_pos)
                menu_button.check_hover(mouse_pos)
                
                if continue_button.is_clicked(mouse_pos, event):
                    # Reset for next mission attempt
                    if player.mission_completed < player.total_missions:
                        # Start next mission based on what's completed
                        if player.mission_completed == 0:
                            start_mission(GameState.PHISHING_MISSION)
                        elif player.mission_completed == 1:
                            start_mission(GameState.PASSWORD_MISSION)
                        elif player.mission_completed == 2:
                            start_mission(GameState.LINK_MISSION)
                        else:
                            start_mission(GameState.SCAM_MISSION)
                    else:
                        game_state = GameState.WIN
                
                if menu_button.is_clicked(mouse_pos, event):
                    game_state = GameState.MENU
            
            # Handle win screen
            elif game_state == GameState.WIN:
                continue_button.check_hover(mouse_pos)
                if continue_button.is_clicked(mouse_pos, event):
                    # Reset game for a new playthrough
                    player = Player()
                    game_state = GameState.MENU
        
        # Draw appropriate screen based on game state
        if game_state == GameState.MENU:
            draw_menu()
        elif game_state == GameState.PHISHING_MISSION:
            draw_phishing_mission()
        elif game_state == GameState.PASSWORD_MISSION:
            draw_password_mission()
        elif game_state == GameState.LINK_MISSION:
            draw_link_mission()
        elif game_state == GameState.SCAM_MISSION:
            draw_scam_mission()
        elif game_state == GameState.GAME_OVER:
            draw_game_over()
        elif game_state == GameState.WIN:
            draw_win()
        
        # Cap the frame rate
        clock.tick(FPS)
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()