# CyberShield Quest

![Game Banner](https://img.shields.io/badge/CyberShield%20Quest-Digital%20Safety%20Game-blue)
![Python Version](https://img.shields.io/badge/Python-3.6%2B-green)
![Pygame](https://img.shields.io/badge/Pygame-2.0%2B-red)
![License](https://img.shields.io/badge/License-MIT-yellow)

An interactive educational game designed to teach digital safety awareness through puzzle-based missions. Built with Pygame for schools and colleges.

## 🎮 Game Overview

CyberShield Quest is a timed, puzzle-based game that educates players about:
- **Phishing Detection** - Identify suspicious emails
- **Password Security** - Create strong passwords
- **Link Safety** - Recognize malicious URLs
- **Scam Prevention** - Respond to online scams safely

### Target Audience
- Schools (Grades 6-12)
- Colleges & Universities
- Digital literacy workshops
- Cybersecurity awareness programs

## 🚀 Features

- **4 Interactive Missions**: Each focusing on different cybersecurity aspects
- **Timed Challenges**: 30-second missions to test quick thinking
- **Score System**: Dynamic Cyber Safety Score (0-100%)
- **Educational Feedback**: Real-time tips and explanations
- **Engaging UI**: Colorful, cyber-themed interface
- **Certificate Award**: Digital certificate upon completion

## 📋 Prerequisites

- Python 3.6 or higher
- Pygame 2.0 or higher
- 100MB free disk space
- 4GB RAM recommended

## 🔧 Installation

### Method 1: Quick Setup (Recommended)

1. **Clone or download the repository:**
```bash
git 
cd cybershield-quest